UniBH - Estruturas de dados - Lista

Implemente os métodos que faltam para uma lista simplesmente encadeada.
